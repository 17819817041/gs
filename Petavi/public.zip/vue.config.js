module.exports = {
    publicPath:"./",
    lintOnSave: false
}