<style lang="less" scoped>
@import "@/less/css.less";
    .headerLogoPage {
        width: 100%;
        height: 109px;
        background: @hdColor;
        position: relative;
        margin-bottom: 10px;
        transition: 0.25s;
        @media screen and (max-width: 1300px) {
            height: 80px;
        }
        .logo {
            background: white;
            position: absolute;
            left: 0;
            top: 0;
            padding: 15px 30px 0 62px;
        }
        .logo img {
            width: 110px;
            height: 123px;
            transition: 0.25s;
            @media screen and (max-width: 1300px) {
                width: 75px;
                height: 85px;
            }
        }
        .helpBtn {
            padding: 0 3px;
            width: 120px;
            height: 40px;
            border-radius: 30px;
            background: @helpBtn;
            
        }
        .logout {
            width: 120px;
            height: 40px;
            border-radius: 30px;
            margin: 0 10px;
            background: @logout;
        }
        .userName {
            width: 250px;
            height: 40px;
            margin-right: 20px;
        }
    }
    .input {
        background: white;
        border-radius: 30px;
        overflow: hidden;
        width: 280px;
    }
    .select {
        padding: 0 15px;
    }
    .headImage {
        border-radius: 50%;
    }
    .name {
        transform: translate(-10%,15%);
    }
    .top {
        margin-top: 10px;
        white-space: nowrap;
    }
    .informationImg {
        margin-top: 3px;
    }
    .div {
        position: absolute;
        width: calc(100% - 240px);
        height: 55px;
        right: 20px;
        bottom: 9px;
        transition: 0.25s;
        @media screen and (max-width: 1300px) {
            width: 80%;
            bottom: 0px;
        }
        @media screen and (max-width: 1200px) {
            right: 0;
        }
    }
    .div .search {
        @media screen and (max-width:1200px) {
            width: 40%;
        }
    }
    .div .function {
        @media screen and (max-width:1200px) {
            width: 60%;
        }
    }
    .div div {
        @media screen and (max-width: 1300px) {
            transition: 0.25s;
            transform: scale(0.9);
        }
    }
    .dropimg {
        padding-left: 5px;
    }
</style>

<template>
    <div class="headerLogoPage">
        <div class="logo">
            <img src="@/assets/img/logo.png" alt="">
        </div>
        <div class="div sb al">
            <div class="search al sa">
                <div class="top" v-if="active" @click="changeIdentity">{{identity}}</div>
                <div class="select top" style="font-size:7px" v-if="active">
                    <div>
                        Category
                        <img class="dropimg" src="@/assets/img/drop.png" alt="">
                    </div>
                </div>
                <div class="input" v-if="active">
                    <el-input prefix-icon="el-icon-search" size="small" placeholder="Search Doctors, Clinics, Hospitals etc."></el-input>
                </div>
            </div>
            <div class="function sb al">
                <div class="userName al sb" v-if="active">
                    <div class="headImage"><img :src="headimg" alt=""></div>      <!-- 头像路径-->
                    <div class="name">{{customerId}}</div>
                    <div class="informationImg cursor top al" @click="information">
                        <img src="@/assets/img/information.png" alt="">
                    </div>
                    <div class="homeImg al cursor" @click="home">
                        <img src="@/assets/img/home.png" alt="">
                    </div>
                </div>
                <div class="logout cursor bold tc white al ju" v-if="active" @click="logout">
                    <div >Logout</div>     
                </div>
                <div class="helpBtn cursor al ju" @click="support">
                    <div class="al">
                        <img src="@/assets/img/what.png" alt="">
                    </div>
                    <div class="suppot size12"> Help & Suppot </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    data () {
        return {
            customerId:'Amily Watson',
            headimg:'@/assets/img/headimg.png',
            identityBoolean: true,
            identity: 'All Doctors'
        }
    },
    props: {
        active: {
            type: Boolean,
            default:true
        }
    },
    created () {
        
    },
    methods: {
        support () {
            this.$router.push({
                name:'support'
            })
        },
        information () {
            this.$router.push("/message")
        },
        home () {
            this.$router.push("/costomerhomepage")
        },
        logout () {
            // localStorage.clear()
            // localStorage.removeItem("Token")
            // this.$router.push("/login")
        },
        changeIdentity () {
            this.identityBoolean = !this.identityBoolean
            if (this.identityBoolean) {
                this.identity = 'All Doctors'
            } else {
                this.identity = "All Patients"
            }
        }
    }
}
</script>

