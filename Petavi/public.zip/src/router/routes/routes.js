export default [
    {
        path: "/",
        redirect: "/login"
    },
    {
        path:"/login",
        name: "login",
        component: () => import("@/view/login/login.vue")
    },
    {
        path:"/customerLogin",
        name: "customerLogin",
        component: () => import("@/view/customerLogin/customerLogin.vue")
    },
    {
        path:'/signUp',
        name:'signUp',
        component: () => import("@/view/signUp/signUp.vue")
    },
    {
        path:'/vetLogin',
        name:'vetLogin',
        component: () => import("@/view/vetLogin/vetLogin.vue")
    },
    {
        path:'/petDetails',
        name:'petDetails',
        component: () => import('@/view/petDetails/petDetails.vue')
    },
    {
        path:'/support',
        name:'support',
        redirect:"/chat",
        component: () => import("@/view/support/support.vue"),
        children:[{
            path:'/chat',
            name:'chat',
            component: () => import("@/view/chat/chat.vue")
        }]
    },
    {
        path:'/customerhomepage',
        name:'customerhomepage',
        component: () => import("@/view/customerhomepage/customerhomepage.vue")
    },
    {
        path:"/petmessage",
        name:'petmessage',
        component: () => import("@/view/petmessage/petmessage.vue")
    },
    {
        path:'/message',
        name:'message',
        component: () => import("@/view/message/message.vue")
    },
    {
        path:'/vethomepage',
        name:'vethomepage',
        component: () => import("@/view/vethomepage/vethomepage.vue")
    },
    {
        path:'/setting',
        name:'setting',
        component: () => import("@/view/setting/setting.vue")
    },
    {
        path:'/reset',
        name:'reset',
        component: () => import("@/view/reset/reset.vue")
    },
    {
        path:'/patients',
        name:'patients',
        component: () => import("@/view/patients/patients.vue")
    },
    {
        path:'/vetSetting',
        name:'vetSetting',
        component: () => import("@/view/vetSetting/vetSetting.vue")
    },
    {
        path:"/agora",
        name:'agora',
        component: () => import("@/view/agora/agora.vue")
    },
    {
        path:"/forgetPwd",
        name:'forgetPwd',
        component: () => import("@/view/forgetPwd/forgetPwd.vue")
    },
    {
        path:"/record",
        name:'record',
        component: () => import("@/view/record/record.vue")
    },
    {
        path:"/appointment",
        name:'appointment',
        component: () => import("@/view/appointment/appointment.vue")
    },
    
]