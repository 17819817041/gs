import request from "./axios"

export function text () {
    return request({
        url: "api/pet/getPet",
        methods:"GET"
    })
}