import axios from "axios"

const service = axios.create({
    baseURL: "http://192.168.10.10:9011/"
})

export default service