<style lang="less" scoped>
@import "@/less/css.less";
    .setting_message {
        width: calc(100% - 125px);
        background: @content;
    }
    .setting_img {
        width: 37px;
        padding-right: 5px;
    }
    .Explan_title {
        width: 96.5%;
        margin: auto;
        padding: 15px 0;
    }
    .personal_message {
        width: 95%;
        box-shadow: 0px 3px 3px 0px #D0D0D0;
        border-radius: 10px;
        height: 400px;
    }
    .size25 {
        font-size: 25px;
        color: @explanTitle;
    }
    .size22 {
        font-size: 22px;
        color: @explanTitle;
    }
    .detail {
        padding: 50px 0;
    }
    .btnColor {
        background: @logout !important;
        border: none !important;
        border-radius: 17px;
        margin-top: 20px;
    }
    .person_image{
        width: 27%;
    } 
    .message1, .message2 {
        width: 30%;
    }
    .name1 div{
        padding-bottom: 6px;
    }
    .name1:nth-child(1) {
        padding-right: 25px;
    }
    .name2 div {
        padding-bottom: 20px;
    }
    .name2:nth-child(1) {
        padding-right: 25px;
    }
</style>

<template>
    <div class="setting">
        <div><myHeaderL></myHeaderL></div>
        <div class="setting_content flex">
            <div><message></message></div>
            <div class="setting_message">
                <div class="explan al Explan_title">
                    <img class="setting_img" src="@/assets/img/setting.png" alt="">
                    Setting
                </div>
                <div class="personal_message mg">
                    <div class="size25 bold tc">Guadian Details</div>
                    <div class="detail flex width100 al">
                        <div class="person_image al ju"><img class="felame" src="@/assets/img/female.png" alt=""></div>
                        <div class="flex" style="width:73%">
                            <div class="message1">   
                                <div class="message1_item ts flex size22 al">
                                    <div class="name1">
                                        <div>User ID</div>
                                        <div>Name</div>
                                        <div>Age</div>
                                        <div>Location</div>
                                        <div>Mobile</div>
                                    </div>
                                    <div class="name1">
                                        <div>666666</div>
                                        <div>666666</div>
                                        <div>666666</div>
                                        <div>666666</div>
                                        <div>666666</div>
                                    </div>
                                </div>   
                            </div>
                            <div class="message2">
                                <div class="message2_item flex ts size22 al">
                                    <div class="name2">
                                        <div>Gender</div>
                                        <div>Preferred Vet</div>
                                        <div>Remarks</div>
                                    </div>
                                    <div class="name2">
                                        <div>666666</div>
                                        <div>666666</div>
                                        <div>666666</div>
                                    </div>
                                </div>
                                <div @click="reset"><el-button class="width100 cursor btnColor" type="primary" :loading="loading">Reset Password</el-button></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    data () {
        return {
            loading:false
        }
    },
    methods: {
        reset () {
            this.loading = true
            setTimeout(() => {
                this.$router.push("/reset")
            },1000)
        }
    }
}
</script>

