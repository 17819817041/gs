<style lang="less" scoped>
@import "@/less/css.less";
    .customer_content {
        .pet_message {
            width: calc(97% - 125px);
            height: 100%;
            background: @content;
            margin-top: 10px;
            @media screen and (max-width:1350px) {
                width: 82%;
            }
            @media screen and (max-width:1200px) {
                width: 98%;
                margin: auto;
            }
        }
    }
    .petMessage_title, .details_item {
        width: 97%;
        margin: auto;
        margin-top: 30px;
    }
    .details_item {
        position: relative;
        background: white;
        border-radius: 8px;
        padding: 70px 0;
        box-shadow: 0px 3px 3px 0px #D0D0D0;
        .edit {
            width: 100px;
            position: absolute;
            border-radius: 20px;
            background: @helpBtn;
            padding: 10px 0px;
            right: 20px;
            top: 20px;
        }
        .save {
            width: 100px;
            position: absolute;
            border-radius: 20px;
            background: @hdColor;
            padding: 10px 0px;
            right: 20px;
            top: 20px;
        }
    }
    .petMessage_title {
        color: #5E5E5E;
    }
    .details_image {
        padding: 0 50px;
        img {
            width: 180px;
            height: 180px;
            padding-left: 50px;
        }
    }
    .details_message {
        width: 400px;
        .about {
            padding: 0 0 7px 30px;
        }
    }
    .noPadding {
        padding: 0 0 4px 30px !important;
    }
    .details_message1 {
        width: 400px;
        .about {
            padding: 0 0 12px 30px;
        }
    }
    .editInp {
        width: 160px;
        border-radius: 30px;
        border: solid 1px gray;
        height: 25px;
        overflow: hidden;
        input {
            padding-left: 10px;
            border: none;
            outline: none;
        }
    }
    .details_images, .details_message, .details_message1 {
        @media screen and (max-width:120px) {}
    }
</style>

<template>
    <div class="customerPage">
        <div><myHeaderL></myHeaderL></div>
        <div class="customer_content flex">
            <div class="present_message">
                <message></message>
            </div>
            <div class="pet_message">
                <div class="bold petMessage_title" @click="toPetMessage">Pet Details</div>
                <div class="details_item size21 flex">
                    <div v-if="change" class="edit cursor tc" @click="edit">Edit</div>
                    <div v-else class="save cursor tc" @click="edit">Save</div>

                    <div class="details_image ju">
                        <img src="@/assets/img/petImage.png" alt="">
                    </div>
                    <div class="details_message flex">
                        <div>
                            <div class="flex about">
                                <div>Pet ID</div>
                            </div>
                            <div class="flex about">
                                <div>Name</div>
                            </div>
                            <div class="flex about">
                                <div>Age</div>
                            </div>
                            <div class="flex about">
                                <div>Pet Type</div>
                            </div>
                            <div class="flex about">
                                <div>Breed</div>
                            </div>
                        </div>
                        <div>
                            <div class="flex about">
                                <div>Pet ID66666666</div>
                            </div>
                            <div :class="['flex', 'about', {noPadding:!change}]">
                                <div v-if="change">Pet ID</div>
                                <div class="editInp al" v-else>
                                    <input type="text">
                                </div>
                            </div>
                            <div :class="['flex', 'about', {noPadding:!change}]">
                                <div v-if="change">Pet ID</div>
                                <div class="editInp al" v-else>
                                    <input type="text">
                                </div>
                            </div>
                            <div class="flex about">
                                <div>Pet ID</div>
                            </div>
                            <div class="flex about">
                                <div>Pet ID</div>
                            </div>
                        </div>
                    </div>
                    <div class="details_message1 flex">
                        <div>
                            <div class="flex about">
                                <div>Gender</div>
                            </div>
                            <div class="flex about">
                                <div>Neutered status</div>
                            </div>
                            <div class="flex about">
                                <div>Weight</div>
                            </div>
                            <div class="flex about">
                                <div>Medical records </div>
                            </div>
                            <div class="flex about">
                                <div>Remarks</div>
                            </div>
                        </div>
                        <div>
                            <div class="flex about">
                                <div>Gender</div>
                            </div>
                            <div class="flex about">
                                <div>Neutered status</div>
                            </div>
                            <div class="flex about">
                                <div>Weight</div>
                            </div>
                            <div class="flex about">
                                <div>Medical records </div>
                            </div>
                            <div class="flex about">
                                <div>Remarks</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    data () {
        return {
            petId:'0000001',
            age:"2 yrs S mo",
            breed:'Husky',
            sex:"M",
            neuteredStatus:'None',
            weight: "33.5kg",

            change:true
        }
    },
    methods: {
        edit () {
            this.change = !this.change
        },
        toPetMessage () {
            this.$router.push({
                name:'petmessage'
            })
        }
    }
}
</script>

