<template>
    <div class="forgetPwd">
        <div><myHeaderL></myHeaderL></div>
        <div class="pwdContent mg">
            <div class="size21 tc pwdTitle">Forget Password</div>
            <div class="size12 tc pwdText">Please enter the email address associated</div>
            <div class="size12 tc pwdText">with your email. We will email you a </div>
            <div class="size12 tc pwdText">link to reset your password.</div>

            <div class="pwdInput">
                <el-form>
                    <el-form-item>
                        <div>
                            <el-input placeholder="Email Address"></el-input>
                        </div>  
                    </el-form-item>
                    <el-form-item>
                        <div>
                            <el-button class="width100" type="primary">Send</el-button>
                        </div>
                    </el-form-item>
                </el-form>
            </div>
            
            
        </div>
    </div>
</template>

<script>
export default {

}
</script>

<style lang="less" scoped>
    @import "@/less/css.less";
    .pwdContent {
        width: 700px;
        margin-top: 150px;
        .pwdTitle {
            padding: 10px !important;
        }
        .pwdText {
            padding: 2px 0;
        }
        .pwdInput {
            margin-top: 17px ;
        }
    }
</style>