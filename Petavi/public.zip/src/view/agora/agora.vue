<style lang="less" scoped>
    .stripe {
        border: solid 1px;
        flex: 10;
    }
    .input {
        border: solid 1px;
        width: 300px;
        height: 50px;
        border-radius: 10px;
        margin: 30px;
    }
    #player1,#player2 {
        width: 300px;
        height: 300px;
        border: solid 1px;
    }
</style>

<template>
    <div class="agora">
        <div class="stripe">
            <div class="input" id="cardNumber"></div>
            <div class="input" id="cardExpiry"></div>
            <div class="input" id="cardCvc"></div>
            <!-- <div id="cardErrors"></div> -->
            <div @click="submit">
                <el-button type="primary">给钱</el-button>
            </div>
        </div>

        <div id="player1"></div>
        <div id="player2"></div>
        <div><button @click="leave">离开</button>
            <button @click="join">进入</button>
        </div>
    </div>
</template>

<script>
export default {
    data () {
        return {
            cardNumber:'',
            cardExpiry:'',
            cardCvc:'',
            stripe:'',


            client:null,
            localTracks : {
                videoTrack: null,
                audioTrack: null
            },
            remoteUsers : {},
            options: {
                appid: '0bc95e1145da4b729993725eb55b319a',
                channel: '888',
                uid: 888,
                token: '0060bc95e1145da4b729993725eb55b319aIAAQPR6KZuQtOdVX1/WckFKw0LFMj+9W2dUlNMSnUaVOil9ppOoAAAAAEABZxLUYwU6qYAEAAQDCTqpg'
            }
        }
    },
    mounted () {
        // console.log(AgoraRTC)
        this.createClient()
        this.getStripe()
    },
    methods: {
        edit () {
            this.change = !this.change
        },
        petList () {
            this.show = !this.show
            this.rotate = !this.rotate
        },
        setting () {
            setTimeout(() => {
                this.$router.push("/setting")
            })
        },
        petDetails () {
            this.$router.push("/petDetails")
        },

        submit () {
            this.stripe.createToken(this.cardNumber,{}).then(res => {
                console.log(res)
            })
        },
        createClient () {
            this.client = this.$V.createClient({  //进入页面自动调用 mounted
                mode: "rtc",
                codec: "vp8"
            })
            this.client.on("user-published", this.handleUserPublished);    //点击join触发
        },
        handleUserPublished (user, mediaType) {
            console.log(1233333, user.uid, mediaType)
            const id = user.uid;
            this.remoteUsers[id] = user;
            this.subscribe(user, mediaType);
        },
        async subscribe (user, mediaType) {
            const uid = user.uid;
            await this.client.subscribe(user, mediaType);
            if (mediaType === 'video') {
                console.log("subscribe success" , uid, this.client.uid);
                user.videoTrack.play(`player2`);
            }
            if (mediaType === 'audio') {
                user.audioTrack.play();
            }
        },
        async join () {
            [ this.options.uid, this.localTracks.audioTrack, this.localTracks.videoTrack ] = await Promise.all([
                // join the channel
                this.client.join(this.options.appid, this.options.channel, this.options.token || null),
                // create local tracks, using microphone and camera
                this.$V.createMicrophoneAudioTrack(),
                this.$V.createCameraVideoTrack()
            ]);
            this.localTracks.videoTrack.play("player1");
            await this.client.publish(Object.values(this.localTracks));
            console.log("publish success");
        },
        async leave() {
            for (var trackName in this.localTracks) {
                var track = this.localTracks[trackName];
                if(track) {
                    track.stop();
                    track.close();
                    this.localTracks[trackName] = undefined;
                }
            }
            // remove remote users and player views
            this.remoteUsers = {};
            // leave the channel
            await this.client.leave();
        },
        getStripe () {
            this.stripe = Stripe("pk_test_51IjH7YCnXywSfyXcBzfaGhIxZURYgDKaCCMu9gJlNctN2R1Li9YOWoK5VUGsaK3CBD2bTbVsRagiCPYKu9ScTcIQ00ZqdIqvDG",{
                locale: 'en'    //修改语言
            })
            var element = this.stripe.elements()
            var elementStyle = {
                base:{
                    lineHeight:'50px'
                }
            }
            this.cardNumber = element.create('cardNumber',{
                style:elementStyle,
                showIcon: true
            })
            this.cardNumber.mount("#cardNumber")
            var elementStyle = {
                base:{
                    lineHeight:'50px'
                }
            }
            this.cardExpiry = element.create('cardExpiry',{
                style:elementStyle,
            })
            this.cardExpiry.mount("#cardExpiry")
            var elementStyle = {
                base:{
                    lineHeight:'50px'
                }
            }
            this.cardCvc = element.create('cardCvc',{
                style:elementStyle
            })
            this.cardCvc.mount("#cardCvc")
        }
    }
}
</script>

