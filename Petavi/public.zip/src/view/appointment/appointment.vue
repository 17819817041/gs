<template>
    <div class="appointment">
        <div><myHeaderL></myHeaderL></div>
        <div class="appointment_content flex">
            <div><vetSetting></vetSetting></div>
            <div class="appointment_content_item">

            </div>
        </div>
    </div>
</template>

<script>
import { text } from "@/axios/request.js"
export default {
    data () {
        return {

        }
    },
    created () {
        text().then(res => {
            console.log(res)
        })
    }
}
</script>

<style lang="less" scoped>
    
</style>